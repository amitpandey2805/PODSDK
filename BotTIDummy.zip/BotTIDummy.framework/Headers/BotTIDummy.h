//
//  BotTIDummy.h
//  BotTIDummy
//
//  Created by Amit on 7/17/20.
//  Copyright © 2020 TelusInternational. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for BotTIDummy.
FOUNDATION_EXPORT double BotTIDummyVersionNumber;

//! Project version string for BotTIDummy.
FOUNDATION_EXPORT const unsigned char BotTIDummyVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BotTIDummy/PublicHeader.h>


