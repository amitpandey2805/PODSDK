//
//  SDKTestPOD.h
//  SDKTestPOD
//
//  Created by Amit on 7/29/20.
//  Copyright © 2020 Xavient. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for SDKTestPOD.
FOUNDATION_EXPORT double SDKTestPODVersionNumber;

//! Project version string for SDKTestPOD.
FOUNDATION_EXPORT const unsigned char SDKTestPODVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SDKTestPOD/PublicHeader.h>


