//
//  DummySDK.h
//  DummySDK
//
//  Created by Amit on 7/13/20.
//  Copyright © 2020 TelusInternational. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DummySDK.
FOUNDATION_EXPORT double DummySDKVersionNumber;

//! Project version string for DummySDK.
FOUNDATION_EXPORT const unsigned char DummySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DummySDK/PublicHeader.h>


